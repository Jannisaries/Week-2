# GED_Base

This is the base project that we created in lab. All player controls are added including looking around with mouse. This base has enemies as well using NavMeshAgent.

If you press "1" button, an item will be instantiated and by clicking RMB, you can drop the item. "2" button will create the same item but with different mass. This part is related to observer pattern which I'll explain more in the class.
